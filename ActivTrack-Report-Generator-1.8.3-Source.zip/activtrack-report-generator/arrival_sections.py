"""Calendar-based arrival sections for date-only ActivTrack ETAs."""
from datetime import timedelta

def arrival_sections(rows, as_of):
    pending=sorted((r for r in rows if r.get('booking_count',0)>0 and r.get('eta')
                    and not r.get('ata') and as_of<=r['eta']<=as_of+timedelta(days=2)),
                   key=lambda r:(r['eta'],r.get('vessel_name',''),r.get('schedule_ref',''),r.get('leg_no',0)))
    today=[r for r in pending if r['eta']==as_of]
    tomorrow=[r for r in pending if r['eta']==as_of+timedelta(days=1)]
    ahead=[r for r in pending if r['eta']==as_of+timedelta(days=2)]
    return [
        ('48-Hour Arrivals - Overview', today+tomorrow, f'{as_of:%d %b %Y} to {as_of+timedelta(days=1):%d %b %Y}'),
        ('Next 24 Hours - Today', today, f'{as_of:%d %b %Y}'),
        ('Tomorrow', tomorrow, f'{as_of+timedelta(days=1):%d %b %Y}'),
        ('Two Days Ahead', ahead, f'{as_of+timedelta(days=2):%d %b %Y}'),
    ]
