# Development

End users should download the portable Windows ZIP from Releases. Source ZIPs do not contain Python or the finished interface.

For development use Windows x64, Python 3.14 with Tk, and Node.js 22+. Create a virtual environment, install requirements.txt, run npm ci and npm run build inside web_ui, then run python polished_app.py from the repository root. Carrier scripts are under carrier_bots. The update button reads stable releases from clemmylk/activtrack-report-generator.

Publish with an explicit allowlist. Exclude runtime state, browser profiles/cookies, API keys, uploaded plans, captured JSON, reports and logs. Never commit local desktop-session.json. Bundle the current source and current UI build together. Preserve licences and limitations. Run relocated-runtime imports, parser/reconciliation checks, UI checks and archive privacy checks before release.
