# ActivTrack Report Generator

**Windows desktop app for authorised sea-import operations teams.** Capture filtered ActivTrack bookings, generate Excel reports, compare carrier schedules and review FCL/container and vessel changes in one workspace.

## Download and start

1. Open [Releases](https://github.com/clemmylk/activtrack-report-generator/releases/latest) and download **ActivTrack-Report-Generator-1.8.3-Windows-x64.zip** under **Assets**. Do not use GitHub's automatically generated source-code ZIP as the installed application.
2. Right-click the downloaded ZIP → **Extract All**. Put the extracted folder somewhere writable, such as Documents. Do not run the app inside the ZIP.
3. Open the extracted folder and double-click **02_START_APP.bat**.
4. Optional: run **01_CREATE_DESKTOP_SHORTCUT.vbs** once to create a desktop shortcut.

**Python, its dependencies and the finished interface are included. No Python or Node installation is required.** Microsoft Edge must be installed. Internet access and your own authorised ActivTrack account are required. Excel or another compatible spreadsheet app is needed to view workbooks.

## Your first report

1. Click **Open ActivTrack**, then sign in using your own account.
2. On the **Bookings** page, choose the date range and any other filters. Wait for the bookings table to load.
3. Return to the app and click **Capture & Generate Excel**. Keep the same Edge page open while capturing.
4. Open the saved report. The source JSON snapshot supports comparison, rebuilding and the tracking tools.
5. Run **Automated Tracking** after capture to check available carrier sites one at a time. Review the resulting workbook and **Live Dashboard**.

Default reports folder: **Documents → ActivTrack Reports**. Change it in Report settings if needed.

## Included tools

| Tool | Purpose |
| --- | --- |
| Reports | Vessel summary, console/co-load booking detail, booking/leg detail, missing ATD/ATA, approaching arrivals and container checks |
| All Vessels | Grouped vessel/schedule report with carrier filters and last notification information where available |
| Automated Tracking | Serial carrier checks against the captured baseline; action-required, priority, manual-check and no-change sheets |
| Manual Carrier Tracking | Paste a vessel list for one carrier; repeated names are skipped |
| Long Term Auto | Paste future sailings, check carrier schedules and compare with captured ActivTrack data |
| Live Dashboard | Separate views for FCL containers and vessel date changes; console changes first |
| Notice Headers & Remarks | Prepare and copy notice text; right-click a dashboard change to copy its header or remarks |
| Arrival / Departure Alerts | Optional alert workflow; some external services require the user's own credentials |

The application reads the configured ActivTrack deployment. It is not a replacement login/account service and is not automatically compatible with every freight system. Carrier availability and site changes affect tracking coverage. **CMA CGM is temporarily excluded from automated runs**; manual tracking remains available. Unsupported or unverified results go to manual review. A missing result is not evidence of arrival.

## Instructions and help

- [User guide](USER_GUIDE.md): report workflow, colour meanings, tracking, dashboard and notices.
- [Troubleshooting](TROUBLESHOOTING.md): startup, Edge sign-in/capture, blocked downloads and no-data results.
- [Privacy and security](PRIVACY_SECURITY.md): local storage and account handling.
- [Release notes](CHANGELOG.md) and [licensing](LICENSE.txt).

This is an **unsigned portable release**, not a signed Windows installer. Windows or company policy may block it. Use your IT team's approval process; do not disable security controls to install it. This package contains no shared login, saved browser session, API key or shipment report.

Copyright Globactive Logistics Sri Lanka | developed by Clement R.

## App updates

Open **Update app** at the bottom of the side menu. Select **Check for updates**, then **Download & install** if a newer stable release is available. When installation is ready, select **Restart updated app**. The update checks the official GitHub release checksum, installs into a separate per-user folder, retargets desktop shortcuts and restores the captured-source/output folder. Finish active tracking/capture work first.

Reports stay in Documents/ActivTrack Reports (or your selected output folder). The previous app copy is retained and can be launched from its original folder if needed. No administrator access is required for the normal per-user installation. Windows/company policies may still block unsigned software.

Versions before 1.8.2 do not have this button. Download and extract 1.8.2 once to enable future in-app updates. The publisher must attach both the matching Windows portable ZIP and SHA256SUMS.txt to each published stable GitHub release. Drafts, prereleases, older versions and incomplete packages are not installed.

FCL checks are now manual only through the FCL dashboard **Check Now** button. Vessel tracking does not start container checks. All vessel-arrival reporting uses sea-vessel ETA, excluding truck legs. Missing sea ETA stays missing. The notice form accepts optional fields and generates a matching header and remarks.

## Loading Plan Check

1. First capture bookings in ActivTrack, or keep an existing captured booking JSON in the selected report output folder.
2. Open **Loading Plan Check** in the side menu (also available in Reports and Overview).
3. Upload XLSX, CSV, TSV, TXT or Markdown, or paste a table with its column headings. XLSX files can contain multiple sheets. Upload limit: 6 MB. PDF, legacy XLS, images and scanned plans are not supported.
4. Select **Check Loading Plan**. The tool uses the newest `ActivTrack_Vessel_Booking_Report_*_Source.json` in the configured output folder; the exact filename is displayed. It does not use live ActivTrack data for this comparison.
5. Review each booking match, VS ID, every captured sea leg, plan vessel/voyage, ETD differences and missing HBL, MBL, container, consignee or cargo quantities. Missing SO alone is not an exception.
6. Expand a row to compare MBL, container, packages, weight and CBM and inspect shared-cell/column-repair notes. Filter/search results or choose **Download comparison CSV** to open the comparison in Excel.

**Match rules:** Identifiers are matched without fuzzy substring matching. Duplicate/ambiguous matches require review. Merged/shared cells and shifted cargo columns are interpreted with notes; inspect those notes before relying on a group-level value. All sea legs are considered; trucks are excluded. Compatible carrier voyage formats are recognized. A consignee suffix/division difference is shown for review.

**Results:** MATCH = supplied comparison values agree; MISMATCH = at least one supplied value differs; MISSING DETAILS = the matched booking lacks required fields; REVIEW = identity/route/plan data requires review; AMBIGUOUS = multiple bookings match; NOT FOUND = no confident identifier match in this capture. A mismatch can also have missing details.

**Capture scope matters:** NOT FOUND is not proof the booking does not exist in ActivTrack. Capture the appropriate date range and recheck. Results do not establish carrier loading, actual arrival or current live schedule accuracy.

This is a local, read-only comparison. It never creates bookings, changes ActivTrack fields or sends notices. Uploaded content is parsed in memory. Exported CSV files and captured reports contain business information and should be kept private.
