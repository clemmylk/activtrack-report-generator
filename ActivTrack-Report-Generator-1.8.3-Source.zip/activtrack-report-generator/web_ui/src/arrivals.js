export function arrivalSections(rows,asOf){
 const base=String(asOf||'').slice(0,10);const d=new Date(base+'T00:00:00Z');
 if(!base||Number.isNaN(+d))return [];
 const day=n=>{const value=new Date(d);value.setUTCDate(value.getUTCDate()+n);return value.toISOString().slice(0,10)};
 const pending=rows.filter(r=>r.booking_count>0&&!r.ata&&r.eta&&String(r.eta).slice(0,10)>=base&&String(r.eta).slice(0,10)<=day(2))
 .sort((a,b)=>String(a.eta).localeCompare(String(b.eta))||String(a.vessel_name).localeCompare(String(b.vessel_name))||String(a.schedule_ref).localeCompare(String(b.schedule_ref))||Number(a.leg_no)-Number(b.leg_no));
 const days=[0,1,2].map(n=>pending.filter(r=>String(r.eta).slice(0,10)===day(n)));
 return [
  {title:'48-Hour Arrivals — Overview',window:base+' to '+day(1),rows:[...days[0],...days[1]]},
  {title:'Next 24 Hours — Today',window:base,rows:days[0]},
  {title:'Tomorrow',window:day(1),rows:days[1]},
  {title:'Two Days Ahead',window:day(2),rows:days[2]},
 ];
}
