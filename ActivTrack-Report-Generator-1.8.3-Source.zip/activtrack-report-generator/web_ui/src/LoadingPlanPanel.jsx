import React,{useState,useRef} from 'react';
import {Upload,Search,Download,ChevronDown,ChevronUp,CheckCircle2,AlertTriangle,FileSpreadsheet} from 'lucide-react';

const show=v=>v===null||v===undefined||v===''?'—':String(v);
const cls=status=>status==='MATCH'?'ok':status==='MISMATCH'?'bad':'review';

export default function LoadingPlanPanel({request}){
 const [paste,setPaste]=useState(''),[file,setFile]=useState(null),[busy,setBusy]=useState(false),[result,setResult]=useState(null),[error,setError]=useState(''),[filter,setFilter]=useState('ALL'),[search,setSearch]=useState(''),[expanded,setExpanded]=useState(null),[editing,setEditing]=useState(true);
 const gate=useRef(false),fileInput=useRef(null);
 async function check(){
  if(gate.current)return;gate.current=true;setBusy(true);setError('');setResult(null);setExpanded(null);
  try{
   let body={text:paste};
   if(file){
    if(file.size>6000000)throw Error('Use a loading plan smaller than 6 MB.');
    const encoded=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('Unable to read this file.'));reader.readAsDataURL(file)});
    body={filename:file.name,file:encoded};
   }
   const checked=await request('loading-plan',body);setResult(checked);setFilter('ALL');setEditing(false);
  }catch(e){setError(e.message)}finally{gate.current=false;setBusy(false)}
 }
 function exportCSV(){
  const columns=['Result','HBL / SO in plan','Booking','VS ID','Plan vessel','Plan voyage','Captured vessel / voyage / route','Missing in capture','Differences','Plan MBL','Captured MBL','Plan container','Captured container','Notes','Source JSON','Plan sheet','Plan row'];
  const safe=v=>{let s=Array.isArray(v)?v.join('; '):show(v);if(/^[=+@\-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'};
  const data=result.rows.map(r=>[r.status,r.hbl,r.bookings,r.vs_id,r.plan.vessel,r.plan.voyage,r.legs.map(l=>`${l.leg}: ${l.vessel} / ${l.voyage} (${l.pol} → ${l.pod})`),r.missing,r.differences,r.plan.mbl,r.current?.mbl,r.plan.container,r.current?.container,r.notes,result.source,r.plan.sheet,r.plan.source_row]);
  const blob=new Blob(['\ufeff'+[columns,...data].map(row=>row.map(safe).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='Loading_Plan_Check_'+result.checked_at.slice(0,10)+'.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 const rows=(result?.rows||[]).map((r,index)=>({...r,index})).filter(r=>(filter==='ALL'||r.status===filter)&&(!search||JSON.stringify(r).toLowerCase().includes(search.toLowerCase())));
 return <div className="page-stack loading-plan-page">
  <div className="page-heading"><h2>Check a loading plan</h2><p>Compare HBLs, vessel, voyage and missing shipment details with the latest booking snapshot. Read only.</p></div>
  {!editing&&result&&<button className="button lp-edit" onClick={()=>setEditing(true)}><Upload size={17}/>Change loading plan</button>}
  {editing&&<section className="card lp-input-card">
   <div className="lp-upload"><FileSpreadsheet size={26}/><div><strong>Upload the loading plan</strong><small>XLSX, CSV, TSV, TXT or Markdown · up to 6 MB</small></div><input ref={fileInput} aria-label="Loading plan file" type="file" accept=".xlsx,.csv,.tsv,.txt,.md" disabled={busy} onChange={e=>{setFile(e.target.files?.[0]||null);setResult(null);setError('')}}/>{file&&<button className="link-button" onClick={()=>{setFile(null);fileInput.current.value='';setResult(null)}} disabled={busy}>Clear file</button>}</div>
   <label className="field">Or paste the loading-plan table<textarea aria-label="Paste loading plan" value={paste} disabled={busy} onChange={e=>{setPaste(e.target.value);setResult(null)}} placeholder="Paste the table from Excel or an email, including column headings. Shared vessel and MBL cells are supported."/></label>
   <div className="row"><span className="muted">{file?`${file.name} will be checked. Pasted text is ignored while a file is selected.`:'Uses the newest captured booking JSON in your report output folder, including all sea legs.'}</span><button className="button red" disabled={busy||(!file&&!paste.trim())} onClick={check}><Search size={18}/>{busy?'Checking…':'Check Loading Plan'}</button></div>
   {error&&<p role="alert" className="error">{error}</p>}
  </section>}
  {result&&<>
   <div className="source lp-source"><strong>Compared with</strong><span>{result.source}</span><small>Snapshot comparison only. “Not found” means absent from this captured date range.</small></div>
   <div className="lp-summary">{[['ALL','All rows',result.rows.length],...Object.entries(result.counts).map(([key,n])=>[key,key.toLowerCase(),n])].map(([key,label,n])=><button key={key} className={filter===key?'selected':''} onClick={()=>setFilter(key)}><strong>{n}</strong><span>{label}</span></button>)}</div>
   <div className="row filters"><label><Search size={17}/><input aria-label="Search loading plan results" placeholder="HBL, booking, VS ID or vessel" value={search} onChange={e=>setSearch(e.target.value)}/></label><button className="button" onClick={exportCSV}><Download size={17}/>Download comparison CSV</button><small>{rows.length} of {result.rows.length} rows</small></div>
   <div className="table-scroll lp-results"><table><thead><tr>{['Result','HBL / consignee','Booking / VS ID','Plan vessel / voyage','Captured sea legs','Missing / differences',''].map((v,i)=><th key={i}>{v}</th>)}</tr></thead><tbody>{rows.map(r=><React.Fragment key={r.index}>
    <tr><td><span className={'lp-status '+cls(r.status)}>{r.status==='MATCH'?<CheckCircle2 size={14}/>:<AlertTriangle size={14}/>} {r.status}</span></td><td><strong>{r.hbl}</strong><small>{r.consignee}</small></td><td><strong>{r.bookings.join(', ')||'—'}</strong><small>{r.vs_id||'—'}</small></td><td><strong>{show(r.plan.vessel)}</strong><small>{show(r.plan.voyage)} · ETD {show(r.plan.etd)}</small></td><td>{r.legs.length?r.legs.map((l,i)=><div className={l.leg===r.matched_leg?'lp-selected-leg':''} key={i}><strong>{l.vessel||'Missing vessel'} / {l.voyage||'Missing voyage'}</strong><small>Leg {l.leg} · {l.pol} → {l.pod} · ETD {show(l.etd)}</small></div>):'No captured sea schedule'}</td><td>{r.missing.length>0&&<div className="lp-missing">Missing: {r.missing.join(', ')}</div>}{r.differences.map((v,i)=><div className="lp-difference" key={i}>{v}</div>)}{!r.missing.length&&!r.differences.length&&<small>{r.status==='MATCH'?'Supplied values match.':r.notes.at(-1)}</small>}</td><td><button className="icon-button" aria-label={'Details '+r.hbl} onClick={()=>setExpanded(expanded===r.index?null:r.index)}>{expanded===r.index?<ChevronUp size={19}/>:<ChevronDown size={19}/>}</button></td></tr>
    {expanded===r.index&&<tr className="lp-detail"><td colSpan="7"><div className="lp-detail-grid">{[['MBL',r.plan.mbl,r.current?.mbl],['Container',r.plan.container,r.current?.container],['Packages',r.plan.pkgs,r.current?.pkgs],['Gross weight',r.plan.weight,r.current?.weight],['CBM',r.plan.cbm,r.current?.cbm]].map(([label,plan,current])=><div key={label}><strong>{label}</strong><small>Plan: {show(plan)}</small><small>Captured: {show(current)}</small></div>)}</div><p><strong>Match basis:</strong> {r.match_basis} · {r.plan.sheet}, row {r.plan.source_row}</p>{r.notes.map((n,i)=><p className="muted" key={i}>{n}</p>)}</td></tr>}
   </React.Fragment>)}</tbody></table>{!rows.length&&<div className="empty">No rows match this filter.</div>}</div>
  </>}
 </div>
}
