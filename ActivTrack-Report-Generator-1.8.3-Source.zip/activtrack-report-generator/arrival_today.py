"""Local, read-only arrival queue and normal-Edge MarineTraffic collector."""
import json,os,re,threading,time
from pathlib import Path
from datetime import datetime,timedelta,timezone
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse
SL=timezone(timedelta(hours=5,minutes=30),'Asia/Colombo')
def name(value):return str(value.get('name') or value.get('code') or '') if isinstance(value,dict) else str(value or '')
def key(value):return re.sub(r'[^A-Z0-9]','',str(value or '').upper())
def stamp():return datetime.now(SL).isoformat(timespec='seconds')
def port_code(value):
    value=key(name(value))
    return 'LKCMB' if value in ('CMB','LKCMB') or 'COLOMBO' in value else value
def read(path,default):
    try:return json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):return default

def candidates(source,tracking,today):
    from report_builder import normalize_source,_build_records
    from sea_legs import sea_legs
    data=read(source,{})
    if not data:return []
    normalized=normalize_source(data);_,legs,_=_build_records(normalized)
    raw={}
    schedules=data.get('schedules') or [b.get('vessel_schedule') for b in data.get('bookings',[]) if b.get('vessel_schedule')]
    for schedule in schedules:
        sea=sea_legs(schedule)
        if sea:
            final=sea[-1];raw[(schedule.get('reference_number'),str(final.get('leg_number')))]=final
    # Carrier data must belong to the same captured source and exact route/leg.
    matched={}
    if str(Path(tracking.get('source') or '.').resolve())==str(Path(source).resolve()):
        for item in tracking.get('rows',[]):
            if item.get('carrier_eta') and item.get('matched'):
                matched[(item.get('vs_id'),str(item.get('leg')))]=item
    rows=[]
    for leg in legs:
        ident=(leg['schedule_ref'],str(leg['leg_no']));original=raw.get(ident)
        if not original or port_code(leg['pod'])!='LKCMB' or leg.get('ata') or not leg.get('booking_count'):continue
        carrier=matched.get(ident,{})
        if carrier and (key(carrier.get('vessel'))!=key(leg['vessel_name']) or key(carrier.get('voyage'))!=key(leg['voyage']) or port_code(carrier.get('pod'))!='LKCMB'):carrier={}
        eta=str(carrier.get('carrier_eta') or leg.get('eta') or '')[:10]
        try:due=datetime.fromisoformat(eta).date()
        except ValueError:continue
        if not today-timedelta(days=7)<=due<=today:continue
        vessel=original.get('vessel') or {};vessel=vessel if isinstance(vessel,dict) else {}
        row={**leg,'id':f'{ident[0]}:{ident[1]}:{key(leg["voyage"])}','vessel':leg['vessel_name'],'vs_id':leg['schedule_ref'],
             'at_eta':str(leg.get('eta') or ''),'eta':eta,'atd':str(leg.get('atd') or ''),
             'imo':str(vessel.get('imo_number') or vessel.get('imo') or ''),'overdue':due<today,
             'advanced':bool(carrier and leg.get('eta') and eta<str(leg['eta']) and due==today),
             'carrier':name(original.get('carrier')),'status':'NOT CHECKED','checked_at':'','source_url':''}
        rows.append(row)
    return sorted(rows,key=lambda r:(r['overdue'],not r['advanced'],r['eta'],r['vessel'],r['vs_id']))

def parse_observation(data,row,now=None):
    now=now or datetime.now(SL);body=data.get('body','');headings=data.get('headings',[])
    obs={'status':'REVIEW DATA','detail':'Vessel identity or arrival evidence is incomplete.','source_url':data.get('url',''),'checked_at':now.isoformat(timespec='seconds'),'port':'','arrival_at':'','nav':''}
    imos=set(re.findall(r'\bIMO\s*:?\s*(\d{7})\b',body,re.I))
    expected=row.get('imo')
    if (expected and expected not in imos) or not any(key(h)==key(row['vessel']) for h in headings) or len(imos)!=1:return obs
    obs['imo']=next(iter(imos))
    nav=re.search(r'Navigational status\s*[:\t ]*\s*(Moored|At anchor|Under way using engine|Underway using engine|Under way|Underway|Stopped|Not under command)',body,re.I)
    received=re.search(r'Position received\s*[:\t ]*\s*(just now|a few seconds ago|\d+\s*(?:seconds?|secs?|minutes?|mins?|hours?|hrs?|days?)\s*ago)',body,re.I)
    age=None
    if received:
        value=received[1].lower();n=re.search(r'\d+',value);age=int(n[0]) if n else 0
        age*=86400 if 'day' in value else 3600 if 'hour' in value or 'hr' in value else 60 if 'min' in value else 1
    obs['ais_age_seconds']=age
    if age is None or age>7200:return {**obs,'status':'STALE / UNAVAILABLE','detail':'AIS position is missing or older than 2 hours.'}
    if not nav:return obs
    obs['nav']=nav[1]
    if 'anchor' in nav[1].lower() or 'stopped' in nav[1].lower():return {**obs,'status':'AT ANCHOR / STOPPED','detail':'Arrival is not confirmed.'}
    if 'moor' not in nav[1].lower():return {**obs,'status':'UNDERWAY','detail':nav[1]}
    port=re.search(r'Arrival at\s+([^\n]+)\n\s*([A-Z]{2})\s*([A-Z]{3})\b',body)
    if not port:return obs
    obs['port']=port[1].strip();obs['port_code']=port[2]+port[3]
    if obs['port_code']!='LKCMB':return {**obs,'status':'OTHER PORT','detail':'Moored at '+obs['port']+'; expected Colombo.'}
    actual=re.search(r'Actual time of arrival\s*:?\s*(\d{4}-\d{2}-\d{2} \d{2}:\d{2})\s*\(UTC([+-]\d+(?::\d+)?)?\)',body,re.I)
    if not actual:return obs
    offset=actual[2] or '+0';hours,_,minutes=offset.lstrip('+-').partition(':');delta=timedelta(hours=int(hours),minutes=int(minutes or 0))*(1 if offset[0]=='+' else -1)
    arrived=datetime.strptime(actual[1],'%Y-%m-%d %H:%M').replace(tzinfo=timezone(delta)).astimezone(SL)
    obs['arrival_at']=arrived.isoformat(timespec='seconds')
    due=datetime.fromisoformat(row['eta']).date()
    if arrived>now+timedelta(minutes=5) or abs((arrived.date()-due).days)>7:return obs
    if row.get('atd') and arrived.date()<datetime.fromisoformat(row['atd'][:10]).date():return obs
    return {**obs,'status':'MOORED AT COLOMBO','detail':'Fresh AIS, matching arrival port and actual-arrival time. Verify shipment before sending notice.'}

class MarineTrafficBrowser:
    def __init__(self):self.driver=None
    def open(self):
        from selenium import webdriver
        if self.driver:
            try:self.driver.current_url;return
            except Exception:self.driver=None
        profile=Path(os.environ.get('LOCALAPPDATA',Path.home()))/'ActivTrackReportGenerator/MarineTrafficProfile';profile.mkdir(parents=True,exist_ok=True)
        options=webdriver.EdgeOptions();options.add_argument('--user-data-dir='+str(profile));options.add_argument('--window-size=1450,1000');options.page_load_strategy='eager'
        self.driver=webdriver.Edge(options=options);self.driver.set_page_load_timeout(35);self.driver.minimize_window()
    def check(self,row,stop,notify):
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        from selenium.webdriver.support.ui import WebDriverWait
        self.open();d=self.driver
        url=row.get('source_url','')
        if urlparse(url).hostname not in ('www.marinetraffic.com','marinetraffic.com') or '/details/ships/' not in url:url=''
        if not url:
            d.get('https://www.marinetraffic.com/en/ais/home')
            def search_box(page):
                if stop.is_set():raise RuntimeError('Stopped')
                for el in page.find_elements(By.CSS_SELECTOR,'input'):
                    if el.is_displayed() and 'search' in ((el.get_attribute('placeholder') or '')+' '+(el.get_attribute('aria-label') or '')).lower():return el
                return False
            try:box=WebDriverWait(d,12).until(search_box)
            except Exception:
                d.maximize_window();notify('MarineTraffic needs login or human verification. Complete it in Edge; waiting up to 60 seconds.')
                box=WebDriverWait(d,60).until(search_box)
            box.clear();box.send_keys(row.get('imo') or row['vessel'])
            def links(page):
                if stop.is_set():raise RuntimeError('Stopped')
                result={}
                for el in page.find_elements(By.CSS_SELECTOR,'a[href*="/details/ships/"]'):
                    label=el.text;href=el.get_attribute('href') or ''
                    if el.is_displayed() and (key(row['vessel']) in key(label) or row.get('imo') and row['imo'] in label):result[href]=el
                if len(result)==1:return next(iter(result.values()))
                return False
            selected=WebDriverWait(d,15).until(links);selected.click()
        else:d.get(url)
        def observation(page):
            if stop.is_set():raise RuntimeError('Stopped')
            data=page.execute_script("return {body:document.body.innerText,headings:[...document.querySelectorAll('h1,h2')].map(x=>x.innerText.trim()),url:location.href}")
            return data if 'Navigational status' in data['body'] else False
        try:data=WebDriverWait(d,15).until(observation)
        except Exception:
            if stop.is_set():raise
            d.maximize_window();notify('MarineTraffic needs verification or login. Waiting up to 60 seconds; no challenge is solved automatically.')
            data=WebDriverWait(d,60).until(observation)
        return parse_observation(data,row)
    def close(self):
        if self.driver:
            try:self.driver.quit()
            except Exception:pass
            self.driver=None

class ArrivalTodayController:
    def __init__(self,folder=None,browser=None):
        self.folder=Path(folder or Path.home()/'Documents/ActivTrack Reports');self.path=self.folder/'Arrival Tracking/state.json'
        self.lock=threading.RLock();self.stop=threading.Event();self.executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='arrival-today');self.browser=browser or MarineTrafficBrowser()
        saved=read(self.path,{});self.rows=saved.get('rows',[]);self.observations=saved.get('observations',{});self.last_checked=saved.get('last_checked','')
        self.busy=False;self.enabled=False;self.message='Ready. Refresh Arrivals checks MarineTraffic.';self.done=0;self.total=0;self.next_check=None;self.source=None;self.tracking={};self.signature=None;self.refresh_due=False
    def sync(self,source,tracking_path):
        if not source or not Path(source).is_file():return
        source=Path(source);tracking_path=Path(tracking_path)
        signature=(str(source),source.stat().st_mtime_ns,tracking_path.stat().st_mtime_ns if tracking_path.exists() else 0,datetime.now(SL).date().isoformat())
        if signature==self.signature:return
        self.signature=signature;self.source=source;self.tracking=read(tracking_path,{})
        self.refresh_due=True
        if not self.busy:self.executor.submit(self.load)
    def load(self):
        if not self.source:return
        rows=candidates(self.source,self.tracking,datetime.now(SL).date())
        with self.lock:
            for row in rows:
                observed=self.observations.get(self.identity(row),{})
                row.update(observed)
                # A saved green result must never outlive its 2-hour AIS freshness.
                if row.get('status')=='MOORED AT COLOMBO':
                    try:age=(datetime.now(SL)-datetime.fromisoformat(row['checked_at'])).total_seconds()+int(row.get('ais_age_seconds') or 0)
                    except (ValueError,KeyError):age=999999
                    if age>7200:row.update(status='STALE / UNAVAILABLE',detail='Saved AIS evidence is stale. Refresh to verify again.')
            self.rows=rows
    @staticmethod
    def identity(row):return '|'.join((key(row['vessel']),key(row['voyage']),str(row['eta']),port_code(row['pod']),str(row.get('atd') or '')))
    def snapshot(self):
        with self.lock:return json.loads(json.dumps({'rows':self.rows,'busy':self.busy,'enabled':self.enabled,'message':self.message,'done':self.done,'total':self.total,'last_checked':self.last_checked,'next_check':self.next_check,'source':str(self.source or '')},default=str))
    def start(self,row_id=None):
        with self.lock:
            if self.busy:return False
            self.busy=True;self.stop.clear();self.done=0;self.message='Preparing arrival checks…';self.enabled=True;self.refresh_due=False
        self.executor.submit(self.work,row_id);return True
    def work(self,row_id):
        try:
            self.load();selected=[r.copy() for r in self.rows if not row_id or r['id']==row_id];self.total=len(selected)
            groups={}
            for row in selected:groups.setdefault((key(row['vessel']),key(row['voyage']),port_code(row['pod'])),[]).append(row)
            for group in groups.values():
                if self.stop.is_set():break
                representative=group[0];self.message='Checking '+representative['vessel']+' / '+representative['voyage']
                try:obs=self.browser.check(representative,self.stop,lambda text:setattr(self,'message',text))
                except Exception:
                    obs={**self.observations.get(self.identity(representative),{}),'status':'NEEDS VERIFICATION' if not self.stop.is_set() else 'CHECK STOPPED','detail':'MarineTraffic was blocked, incomplete or unavailable. Complete login/verification in the dedicated Edge session, then Refresh Arrivals.','checked_at':stamp()}
                    # One blocked site must not cause a full minute of retries for every ship.
                    self.enabled=False
                if self.stop.is_set():break
                with self.lock:
                    for row in self.rows:
                        if (key(row['vessel']),key(row['voyage']),port_code(row['pod']))==(key(representative['vessel']),key(representative['voyage']),port_code(representative['pod'])):
                            verified=dict(obs)
                            if verified.get('status')=='MOORED AT COLOMBO':
                                arrival=datetime.fromisoformat(verified['arrival_at']).date()
                                if abs((arrival-datetime.fromisoformat(row['eta']).date()).days)>7 or row.get('atd') and arrival<datetime.fromisoformat(row['atd'][:10]).date():verified.update(status='REVIEW DATA',detail='Arrival timing does not match this schedule leg.')
                            self.observations[self.identity(row)]=verified;row.update(verified)
                    self.done+=len(group);self.save()
                if obs['status']=='NEEDS VERIFICATION':break
            self.last_checked=stamp();self.message=('Stopped; previous results retained.' if self.stop.is_set() else 'MarineTraffic needs verification. Automatic checks paused; complete it in Edge and press Refresh Arrivals.' if not self.enabled else f'Checked {self.done} of {self.total} arrival rows.')
        except Exception as exc:self.message='Arrival check needs attention: '+str(exc)
        finally:
            with self.lock:
                self.busy=False;self.next_check=(datetime.now(SL)+timedelta(hours=1)).isoformat(timespec='seconds') if self.enabled else None;self.save()
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True);temp=self.path.with_suffix('.tmp');temp.write_text(json.dumps({'rows':self.rows,'observations':self.observations,'last_checked':self.last_checked},default=str,indent=2),encoding='utf-8');temp.replace(self.path)
    def tick(self,other_busy=False):
        if self.enabled and not self.busy and not other_busy and (self.refresh_due or self.next_check and datetime.now(SL)>=datetime.fromisoformat(self.next_check)):self.start()
    def halt(self):self.enabled=False;self.stop.set();self.next_check=None;self.message='Stopping checks…' if self.busy else 'Checks stopped.'
    def close(self):self.halt();self.executor.submit(self.browser.close);self.executor.shutdown(wait=False,cancel_futures=False)
