"""Read-only loading-plan reconciliation against a captured ActiveTrack snapshot."""
import base64
import csv
import io
import json
import re
import zipfile
from collections import Counter
from datetime import date, datetime
from pathlib import Path

from sea_legs import sea_legs

ALIASES = {
    'hbl': ['hbl', 'hbl no', 'hbl number', 'house bl no'],
    'so': ['so', 'so no', 'so number'],
    'consignee': ['consignee', 'customer'],
    'vessel_voyage': ['new vessel voy', 'vessel voy', 'vessel voyage', 'new vessel voyage'],
    'vessel': ['vessel', 'vessel name', 'new vessel'],
    'voyage': ['voyage', 'voy', 'voyage no'],
    'etd': ['etd shenzhen', 'etd', 'etd pol'],
    'mbl_container': ['mbl container', 'mbl container no'],
    'mbl': ['mbl', 'mbl no', 'mbl number'],
    'container': ['container', 'container no', 'container number'],
    'invoice': ['invoice no', 'invoice', 'po', 'po no'],
    'pkgs': ['pkgs', 'packages', 'no of packages', 'pkg'],
    'weight': ['gw kgs', 'gw', 'gross weight', 'kgs', 'weight'],
    'cbm': ['cbm', 'volume', 'cbm volume'],
    'packing': ['loose palletized', 'packing'],
    'ready': ['cargo ready date'],
    'warehouse': ['cargo s arrival date at wh', 'cargos arrival date at wh', 'arrival date at wh'],
}


def text(v):
    if isinstance(v, dict):
        return text(v.get('name') or v.get('label') or '')
    if isinstance(v, (datetime, date)):
        return v.isoformat()[:10]
    return str(v if v is not None else '').replace('\xa0', ' ').strip()


def norm(v):
    return re.sub(r'[^A-Z0-9]', '', text(v).upper())


def header(v):
    return re.sub(r'[^a-z0-9]+', ' ', text(v).lower()).strip()


def missing(v):
    return norm(v) in ('', 'TBA', 'NA', 'NIL', 'NONE', 'NULL', 'PENDING', 'TBC', 'NOTAVAILABLE')


def number(v):
    try:
        return float(text(v).replace(',', ''))
    except ValueError:
        return None


def day(v):
    s = text(v)
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%d/%m/%Y', '%d-%b-%Y'):
        try:
            return datetime.strptime(s[:10] if fmt != '%d-%b-%Y' else s, fmt).date().isoformat()
        except ValueError:
            pass
    return ''


def voyage(v):
    s = norm(v)
    # Direction-first and direction-last carrier spellings describe the same voyage.
    m = re.fullmatch(r'([NEWS])(\d+)', s)
    return m[2] + m[1] if m else s


def same_voyage(a, b):
    aa, bb = voyage(a), voyage(b)
    if not aa or not bb:
        return False
    return aa == bb or any(voyage(p) == aa for p in re.split(r'[-/\s]+', text(b))) or any(voyage(p) == bb for p in re.split(r'[-/\s]+', text(a)))


def split_vessel(v):
    s = text(v).upper().strip()
    m = re.match(r'^(.*?)\s*[/ ]\s*([A-Z0-9-]*\d[A-Z0-9-]*)\s*$', s)
    # Do not mistake the numeric vessel suffix (WAN HAI 516) for a voyage.
    if m and re.search(r'[A-Z]', m[2]) and not missing(m[1]):
        return m[1].strip(' /'), m[2]
    return s, ''


def identifiers(value):
    s = text(value).upper()
    # Only explicit complete identifier tokens, never substring/fuzzy matching.
    return {norm(x) for x in re.findall(r'[A-Z0-9]+(?:[/-][A-Z0-9]+)*', s) if re.search(r'\d', x)}


def id_matches(wanted, actual):
    w, a = norm(wanted), norm(actual)
    return bool(w and (w == a or w in identifiers(actual) or
        (re.fullmatch(r'GXH\d+[A-Z]?', w) and re.search(r'(?<![A-Z0-9])' + re.escape(w) + r'(?![A-Z0-9])', text(actual).upper()))))


def grids(payload):
    name = text(payload.get('filename'))
    if payload.get('file'):
        try:
            raw = base64.b64decode(payload['file'], validate=True)
        except Exception as exc:
            raise ValueError('The uploaded file could not be read.') from exc
        if len(raw) > 6_000_000:
            raise ValueError('Use a loading plan smaller than 6 MB.')
        if Path(name).suffix.lower() == '.xlsx':
            from openpyxl import load_workbook
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                if sum(i.file_size for i in archive.infolist()) > 35_000_000:
                    raise ValueError('This workbook is too large. Upload just the loading-plan sheet.')
            wb = load_workbook(io.BytesIO(raw), data_only=True, read_only=False)
            result = []
            for ws in wb.worksheets:
                if ws.max_row > 10000 or ws.max_column > 120:
                    raise ValueError('Limit the workbook to 10,000 rows and 120 columns.')
                rows = [list(r) for r in ws.iter_rows(values_only=True)]
                # Respect merged source cells, including horizontal group headings.
                for merged in ws.merged_cells.ranges:
                    value = rows[merged.min_row-1][merged.min_col-1]
                    if merged.max_col == merged.min_col:
                        for y in range(merged.min_row-1, merged.max_row):
                            rows[y][merged.min_col-1] = value
                result.append((ws.title, rows))
            wb.close()
            return result
        if Path(name).suffix.lower() not in ('.csv', '.tsv', '.txt', '.md'):
            raise ValueError('Upload XLSX, CSV, TSV or TXT, or paste the table. PDF/images are not supported yet.')
        try:
            value = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            value = raw.decode('cp1252')
    else:
        value = text(payload.get('text'))
    if not value:
        raise ValueError('Upload a loading plan or paste its table first.')
    if len(value) > 1_000_000:
        raise ValueError('The pasted table is too large.')
    lines = [s for s in value.splitlines() if s.strip()]
    if any('|' in s for s in lines[:5]):
        rows = [[c.strip().replace('**', '').replace('<br>', ' ').replace('<br/>', ' ') for c in s.strip().strip('|').split('|')] for s in lines]
        rows = [r for r in rows if not all(re.fullmatch(r'[:\-\s]*', c) for c in r)]
    else:
        try:
            dialect = csv.Sniffer().sniff(value[:10000], delimiters=',\t;')
        except csv.Error:
            dialect = csv.excel_tab
        rows = list(csv.reader(io.StringIO(value), dialect))
    return [(name or 'Pasted table', rows)]


def parse_plan(payload):
    result, warnings = [], []
    lookup = {alias: key for key, values in ALIASES.items() for alias in values}
    for sheet, rows in grids(payload):
        mapping = None
        context = {}
        for rownum, cells in enumerate(rows, 1):
            cells = [text(c) for c in cells]
            found = {lookup[header(c)]: i for i, c in enumerate(cells) if header(c) in lookup}
            if ('hbl' in found or 'so' in found) and len(found) >= 3:
                mapping, context = found, {}
                continue
            if mapping is None:
                continue
            row = {k: cells[i] if i < len(cells) else '' for k, i in mapping.items()}
            if missing(row.get('hbl')) and missing(row.get('so')):
                if any(cells):
                    context = {}  # A separator/total is a group boundary.
                continue
            row.update(sheet=sheet, source_row=rownum, notes=[])
            # Repair flattened merged-cell rows using the cargo tail, not the shifted column titles.
            packing = next((i for i, c in enumerate(cells) if header(c) in ('loose', 'palletized', 'palletised')), None)
            if packing is not None and packing >= 2 and packing+1 < len(cells) and number(cells[packing-2]) is not None and number(cells[packing-1]) is not None:
                if mapping.get('packing') != packing:
                    row['notes'].append('Shifted cargo columns restored from the packing marker.')
                    # The original vessel/ETD/MBL headings no longer apply in a shifted row.
                    for key in ('mbl_container','mbl','container','invoice','vessel_voyage','vessel','voyage','etd'):
                        if mapping.get(key, -1) >= packing-2:
                            row[key] = ''
                    inv_index = mapping.get('mbl_container', mapping.get('invoice', -1))
                    if 0 <= inv_index < packing-2:
                        row['invoice'] = cells[inv_index]
                        if inv_index == mapping.get('mbl_container'):
                            row['mbl_container'] = ''
                row.update(pkgs=cells[packing-2], weight=cells[packing-1], packing=cells[packing], cbm=cells[packing+1])
            combined = row.get('vessel_voyage', '')
            if combined and not missing(combined):
                row['vessel'], row['voyage'] = split_vessel(combined)
            if any(not missing(row.get(k)) and context.get(k) and norm(row[k])!=norm(context[k]) for k in ('vessel','voyage')):
                context = {}  # Never carry an MBL/container into a different sailing group.
            combo = row.get('mbl_container', '')
            boxes = re.findall(r'\b[A-Z]{4}\s*\d{7}\b', combo.upper())
            if boxes:
                row['container'] = ', '.join(norm(c) for c in boxes)
                combo = re.sub(r'\b[A-Z]{4}\s*\d{7}\b', '', combo, flags=re.I).strip(' /,;')
            if combo:
                # A combined MBL/container column can also contain PO/invoice data.
                if (re.fullmatch(r'[A-Z]{2,5}\d{6,}', norm(combo)) or re.fullmatch(r'\d{3}G\d{6,}', norm(combo))) and not norm(combo).startswith(('PO', 'GXH')):
                    row['mbl'] = combo
                else:
                    row['notes'].append('Combined MBL/container value needs review; not assumed to be an MBL: '+combo)
            for key in ('vessel', 'voyage', 'etd', 'mbl', 'container'):
                if not missing(row.get(key)):
                    context[key] = row[key]
                elif key in context:
                    row[key] = context[key]
                    row['notes'].append(key.upper()+' shared from the preceding plan row.')
            if not row.get('vessel'):
                row['notes'].append('Plan vessel is missing; vessel accuracy cannot be confirmed.')
            if not row.get('voyage'):
                row['notes'].append('Plan voyage is missing; voyage accuracy cannot be confirmed.')
            result.append(row)
    if not result:
        raise ValueError('No loading-plan rows found. Include a header row with HBL (or SO), consignee and vessel/cargo columns.')
    if len(result) > 3000:
        raise ValueError('Check up to 3,000 loading-plan rows at a time.')
    return result, warnings


def latest_snapshot(folder):
    root = Path(folder or Path.home()/'Documents'/'ActivTrack Reports')
    files = list(root.glob('ActivTrack_Vessel_Booking_Report_*_Source.json'))
    if not files:
        raise ValueError('No captured booking JSON found in the report folder. Capture bookings or choose the correct output folder first.')
    # A rebuilt old file must not outrank a newer capture solely because it was touched.
    return max(files, key=lambda p: (p.name, p.stat().st_mtime_ns))


def compare_plan(plan, source):
    bookings = [b for b in source.get('bookings', []) if isinstance(b, dict) and not b.get('deleted_at')]
    known = {text(b.get('reference_number')) for b in bookings}
    bookings += [b for b in source.get('incomplete_bookings',[]) if isinstance(b,dict) and not b.get('deleted_at') and text(b.get('reference_number')) not in known]
    schedules = {str(s.get('id')): s for s in source.get('schedules', []) if isinstance(s, dict)}
    rows = []
    for p in plan:
        hbl, so = p.get('hbl', ''), p.get('so', '')
        candidates = [b for b in bookings if (not missing(hbl) and id_matches(hbl, b.get('hbl_number'))) or (not missing(so) and id_matches(so, b.get('so_number')))]
        basis = 'HBL / SO'
        if not candidates and not missing(hbl):
            candidates = [b for b in bookings if id_matches(hbl, b.get('so_number'))]
            basis = 'Plan HBL matched SO only — verify identity'
        # Duplicate rows in a source capture represent the same booking, not two candidates.
        candidates = list({str(b.get('id') or b.get('reference_number') or id(b)): b for b in candidates}.values())
        out = {'hbl':hbl or so, 'consignee':p.get('consignee',''), 'plan':p, 'bookings':[], 'vs_id':'', 'legs':[], 'missing':[], 'differences':[], 'notes':list(p['notes']), 'status':'NOT FOUND', 'match_basis':basis}
        if len(candidates) != 1:
            out['status'] = 'AMBIGUOUS' if candidates else 'NOT FOUND'
            out['bookings'] = [b.get('reference_number') for b in candidates]
            out['notes'].append('Conflicting or absent identifier match; no booking was selected. Search scope is the selected captured report only.')
            rows.append(out)
            continue
        b = candidates[0]
        if so and not missing(so) and not id_matches(so,b.get('so_number')):
            out['differences'].append('SO conflicts with the HBL-matched booking.')
        out['bookings'] = [b.get('reference_number') or str(b.get('id'))]
        nested = b.get('vessel_schedule') if isinstance(b.get('vessel_schedule'),dict) else {}
        s = schedules.get(str(b.get('vessel_schedule_id'))) or nested
        out['vs_id'] = text(b.get('vessel_schedule_reference_number') or s.get('reference_number'))
        out['current'] = {k:b.get(v) for k,v in {'mbl':'mbl_number','container':'container_number','consignee':'customer_name','pkgs':'no_of_packages','weight':'gross_weight','cbm':'cbm_volume','so':'so_number','hbl':'hbl_number'}.items()}
        out['legs'] = [{'leg':l.get('leg_number'),'vessel':text(l.get('vessel_name') or l.get('vessel')), 'voyage':text(l.get('voyage')), 'pol':text(l.get('departure_port') or l.get('pol')), 'pod':text(l.get('arrival_port') or l.get('pod')), 'etd':text(l.get('etd'))} for l in sea_legs(s)]
        if not out['legs']:
            out['missing'].append('Vessel schedule / sea leg')
        matched = [l for l in out['legs'] if norm(l['vessel']) == norm(p.get('vessel'))] if p.get('vessel') else []
        exact = [l for l in matched if same_voyage(p.get('voyage'),l['voyage'])]
        selected = exact[0] if len(exact)==1 else matched[0] if len(matched)==1 else None
        if p.get('vessel') and out['legs'] and not matched:
            out['differences'].append('Vessel differs: '+p['vessel']+' not found on any captured sea leg.')
        elif matched and p.get('voyage') and not exact:
            out['differences'].append('Voyage differs: plan '+p['voyage']+'; captured '+', '.join(l['voyage'] or 'MISSING' for l in matched))
        if len(exact)>1:
            out['notes'].append('Vessel/voyage appears on more than one sea leg; route needs review.')
        if selected:
            out['matched_leg'] = selected['leg']
            if not selected['voyage']:
                out['missing'].append('Voyage')
            if day(p.get('etd')) and day(selected['etd']) and day(p['etd']) != day(selected['etd']):
                out['differences'].append('ETD differs: plan '+day(p['etd'])+'; captured '+day(selected['etd']))
            elif day(p.get('etd')) and not day(selected['etd']):
                out['missing'].append('ETD')
        for label, key in [('HBL','hbl'),('MBL','mbl'),('Container','container'),('Consignee','consignee')]:
            current = out['current'][key]
            if missing(current):
                out['missing'].append(label)
            elif p.get(key) and not missing(p[key]):
                same = norm(current)==norm(p[key])
                if key=='hbl':
                    same = id_matches(p[key],current)
                if key=='container':
                    same = set(re.findall(r'[A-Z]{4}\d{7}', norm(p[key]))) <= set(re.findall(r'[A-Z]{4}\d{7}', norm(current)))
                if key=='consignee':
                    def company(v):
                        return re.sub(r'\b(?:PRIVATE|PVT|LIMITED|LTD|COMPANY|CO)\b', '', re.sub(r'[^A-Z0-9]+',' ',text(v).upper())).split()
                    same = company(current)==company(p[key])
                if not same:
                    out['differences'].append(label+' differs: plan '+text(p[key])+'; captured '+text(current))
        for label,key,tolerance in [('Packages','pkgs',0),('Gross weight','weight',.02),('CBM','cbm',.001)]:
            pv, av = number(p.get(key)), number(out['current'].get(key))
            if av is None or av<=0:
                out['missing'].append(label)
            elif pv is not None and abs(pv-av)>tolerance:
                out['differences'].append(label+' differs: plan '+str(pv)+'; captured '+str(av))
        out['status'] = 'MISMATCH' if out['differences'] else 'MISSING DETAILS' if out['missing'] else 'REVIEW' if not p.get('vessel') or not p.get('voyage') or basis.startswith('Plan HBL') or len(exact)>1 else 'MATCH'
        rows.append(out)
    return rows


def check_loading_plan(payload, folder):
    plan, warnings = parse_plan(payload)
    path = latest_snapshot(folder)
    source = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(source.get('bookings'),list):
        raise ValueError('The latest source has no booking array. Capture a fresh booking report.')
    rows = compare_plan(plan, source)
    return {'source':path.name, 'checked_at':datetime.now().astimezone().isoformat(), 'captured_at':source.get('capture',{}), 'filter':source.get('filter',{}), 'plan_name':payload.get('filename') or 'Pasted loading plan', 'rows':rows, 'counts':dict(Counter(r['status'] for r in rows)), 'warnings':warnings, 'read_only':True}
